import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <h1 className="text-4xl font-bold mb-4">Tailwind is working 🎉</h1>
      <p className="text-lg">This is styled with Tailwind CSS.</p>
    </div>
  )
}

export default App
